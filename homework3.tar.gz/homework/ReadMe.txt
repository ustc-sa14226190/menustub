
/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  ReadMe.txt                             */
/*  PRINCIPAL AUTHOR      :  LiYunpeng                              */
/*  SUBSYSTEM NAME        :  Menu                                   */
/*  MODULE NAME           :  Menu                                   */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/28                             */
/*  DESCRIPTION           :  Readme of MenuStub                     */
/********************************************************************/

    menu.c is the stud of menu.h and test.c is the driver of this stub.

    use "gcc linktable.h linktable.c menu.h menu.c test.c -o test.o" to get 
the executable file test.o, then use "./test.o" to test the driver.

    In my program, I test a function twice: with right inputs and wrong inputs.
And for every input, it reports the expected results, the real results. 
